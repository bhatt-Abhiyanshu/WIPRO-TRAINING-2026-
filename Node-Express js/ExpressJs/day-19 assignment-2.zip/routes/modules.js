const a = require("express")
const b = a.Router()

const c = (d, e, f) => {
  if (!/^[0-9]+$/.test(d.params.code)) {
    return e.status(400).json({ error: "Invalid course ID" })
  }
  f()
}

b.get("/:code", c, (d, e) => {
  e.json({ id: d.params.code, name: "React Mastery", duration: "6 weeks" })
})

module.exports = b
