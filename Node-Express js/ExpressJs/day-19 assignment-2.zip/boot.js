const x = require("express")
const y = x()
const z = require("./routes/modules")

y.use(x.json())

y.get("/", (a, b) => {
  b.send("Welcome to SkillSphere LMS API")
})

y.use("/courses", z)

y.use((a, b) => {
  b.status(404).json({ error: "Route not found" })
})

y.listen(4000, () => {
  console.log("Active on 4000")
})
