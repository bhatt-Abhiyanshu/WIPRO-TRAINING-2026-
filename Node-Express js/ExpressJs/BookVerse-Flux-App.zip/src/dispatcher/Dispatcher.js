class Dispatcher {
  constructor() {
    this.callbacks = [];
  }
  register(cb) {
    this.callbacks.push(cb);
  }
  dispatch(action) {
    this.callbacks.forEach(cb => cb(action));
  }
}
export default new Dispatcher();