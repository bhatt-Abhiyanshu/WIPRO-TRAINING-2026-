import React from "react";
import BookForm from "./components/BookForm";
import BookList from "./components/BookList";

export default function App() {
  return (
    <div>
      <h1>BookVerse</h1>
      <BookForm />
      <BookList />
    </div>
  );
}