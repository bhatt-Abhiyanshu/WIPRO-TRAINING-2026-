import dispatcher from "../dispatcher/Dispatcher";

let books = [];
let listeners = [];

const BookStore = {
  getBooks() {
    return books;
  },
  addListener(fn) {
    listeners.push(fn);
  }
};

dispatcher.register(action => {
  if (action.type === "ADD_BOOK") {
    books.push(action.payload);
    listeners.forEach(l => l());
  }
});

export default BookStore;