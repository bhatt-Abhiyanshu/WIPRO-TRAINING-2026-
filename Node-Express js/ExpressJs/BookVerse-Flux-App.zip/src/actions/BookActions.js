import dispatcher from "../dispatcher/Dispatcher";

export const addBook = (book) => {
  dispatcher.dispatch({
    type: "ADD_BOOK",
    payload: book
  });
};