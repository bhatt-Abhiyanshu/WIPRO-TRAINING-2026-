import React from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import { addBook } from "../actions/BookActions";

export default function BookForm() {
  const formik = useFormik({
    initialValues: { title: "", author: "", price: "" },
    validationSchema: Yup.object({
      title: Yup.string().required(),
      author: Yup.string().required(),
      price: Yup.number().required()
    }),
    onSubmit: values => {
      addBook(values);
      formik.resetForm();
    }
  });

  return (
    <form onSubmit={formik.handleSubmit}>
      <input name="title" placeholder="Title" onChange={formik.handleChange} value={formik.values.title} />
      <input name="author" placeholder="Author" onChange={formik.handleChange} value={formik.values.author} />
      <input name="price" placeholder="Price" onChange={formik.handleChange} value={formik.values.price} />
      <button type="submit">Add Book</button>
    </form>
  );
}