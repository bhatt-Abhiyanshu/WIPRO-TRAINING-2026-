import React, { useEffect, useState } from "react";
import BookStore from "../store/BookStore";

export default function BookList() {
  const [books, setBooks] = useState(BookStore.getBooks());

  useEffect(() => {
    BookStore.addListener(() => setBooks([...BookStore.getBooks()]));
  }, []);

  return (
    <ul>
      {books.map((b, i) => (
        <li key={i}>{b.title} - {b.author} - ₹{b.price}</li>
      ))}
    </ul>
  );
}