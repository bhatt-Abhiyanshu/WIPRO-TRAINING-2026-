const web = require("express")
const router = web.Router()

let archive = [
  { uid: 1, name: "1984", writer: "Orwell" },
  { uid: 2, name: "The Alchemist", writer: "Coelho" }
]

router.get("/", (req, res) => {
  res.json(archive)
})

router.get("/:uid", (req, res) => {
  const item = archive.find(b => b.uid == req.params.uid)
  if (!item) return res.status(404).send("Book not found")
  res.json(item)
})

router.post("/", (req, res) => {
  const { name, writer } = req.body
  if (!name || !writer) return res.status(400).send("Invalid data")
  const record = { uid: Date.now(), name, writer }
  archive.push(record)
  res.status(201).json(record)
})

router.put("/:uid", (req, res) => {
  const index = archive.findIndex(b => b.uid == req.params.uid)
  if (index === -1) return res.status(404).send("Book not found")
  archive[index] = { ...archive[index], ...req.body }
  res.json(archive[index])
})

router.delete("/:uid", (req, res) => {
  archive = archive.filter(b => b.uid != req.params.uid)
  res.send("Deleted")
})

module.exports = router
