const web = require("express")
const engine = web()
const shelf = require("./api/library")

engine.use(web.json())

engine.use((req, res, next) => {
  const stamp = new Date().toISOString()
  console.log(`[${stamp}] ${req.method} ${req.originalUrl}`)
  next()
})

engine.get("/", (req, res) => {
  res.send("Welcome to Express Server")
})

engine.get("/status", (req, res) => {
  res.json({ server: "running", uptime: "OK" })
})

engine.get("/products", (req, res) => {
  const key = req.query.name
  if (key) {
    res.json({ query: key })
  } else {
    res.send("Please provide a product name")
  }
})

engine.use("/books", shelf)

engine.use((req, res) => {
  res.status(404).send("Route not found")
})

engine.use((err, req, res, next) => {
  console.error(err.message)
  res.status(500).json({ error: "Internal Server Error" })
})

engine.listen(4000, () => {
  console.log("Server active on port 4000")
})
