const { DataTypes } = require("sequelize");

module.exports = (sequelize) => {
  return sequelize.define("Instructor", {
    name: DataTypes.STRING
  });
};
