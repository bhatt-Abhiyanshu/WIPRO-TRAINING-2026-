const express = require("express");
const { Sequelize } = require("sequelize");
require("dotenv").config();

const app = express();

const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    dialect: "mysql"
  }
);

const InstructorModel = require("./models/Instructor");
const CourseModel = require("./models/Course");

const Instructor = InstructorModel(sequelize);
const Course = CourseModel(sequelize);

Instructor.hasMany(Course);
Course.belongsTo(Instructor);

sequelize.sync();

app.get("/instructor/:id/courses", async (req, res) => {
  const courses = await Course.findAll({
    where: { InstructorId: req.params.id }
  });
  res.json(courses);
});

app.listen(process.env.PORT);
