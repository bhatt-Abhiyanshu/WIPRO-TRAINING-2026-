const express = require("express");
require("dotenv").config();
const db = require("./db");

const app = express();
app.use(express.json());

app.post("/courses", (req, res) => {
  const { title, price } = req.body;
  db.query(
    "INSERT INTO courses (title, price) VALUES (?, ?)",
    [title, price],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: "Course inserted successfully" });
    }
  );
});

app.listen(process.env.PORT);
