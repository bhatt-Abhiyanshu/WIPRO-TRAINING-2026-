const mongoose = require("mongoose");

const enrollmentSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  course: String
});

module.exports = mongoose.model("Enrollment", enrollmentSchema);
