const express = require("express");
const mongoose = require("mongoose");
require("dotenv").config();

const User = require("./models/User");
const Enrollment = require("./models/Enrollment");

const app = express();
app.use(express.json());

mongoose.connect(process.env.MONGO_URL);

app.get("/enrollments", async (req, res) => {
  const data = await Enrollment.find().populate("user");
  res.json(data);
});

app.listen(process.env.PORT);
