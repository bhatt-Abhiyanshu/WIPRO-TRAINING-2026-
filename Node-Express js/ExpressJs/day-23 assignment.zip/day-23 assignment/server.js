
// Day 23 Assignment - File Uploads & Real-Time Communication

const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Ensure uploads folder exists
if (!fs.existsSync('./uploads')) {
    fs.mkdirSync('./uploads');
}

// -----------------------
// Multer Configuration
// -----------------------

// Storage configuration
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        // Sanitize file name (replace spaces with underscores)
        const sanitizedName = file.originalname.replace(/\s+/g, '_');
        cb(null, sanitizedName);
    }
});

// Allow only PDF files
const fileFilter = (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
        cb(null, true);
    } else {
        cb(new Error('Only PDF files are allowed'), false);
    }
};

// Limit file size to 5MB
const upload = multer({
    storage,
    fileFilter,
    limits: { fileSize: 5 * 1024 * 1024 }
});

// -----------------------
// Routes
// -----------------------

// Upload Route
app.post('/upload', upload.single('file'), (req, res) => {
    res.send(`File uploaded successfully: ${req.file.filename}`);
});

// Serve static uploaded files
app.use('/materials', express.static(path.join(__dirname, 'uploads')));

// Serve chat frontend
app.use(express.static(path.join(__dirname, 'public')));

// -----------------------
// Socket.io Real-Time Chat
// -----------------------

io.on('connection', (socket) => {
    console.log('User connected');

    socket.on('chatMessage', (msg) => {
        io.emit('chatMessage', msg);
    });

    socket.on('disconnect', () => {
        console.log('User disconnected');
    });
});

// -----------------------
// Start Server
// -----------------------

server.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
