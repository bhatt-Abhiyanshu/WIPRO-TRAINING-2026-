const rateLimit = require("express-rate-limit")

module.exports = rateLimit({
  windowMs: 60000,
  max: 5,
  handler: (req, res) => res.status(429).json({ error: "Too many requests" })
})