const Course = require("../models/Course")

const getCourses = async (req, res, next) => {
  try {
    const courses = await Course.find()
    res.json(courses)
  } catch (e) {
    next(e)
  }
}

const createCourse = async (req, res, next) => {
  try {
    const course = await Course.create(req.body)
    res.status(201).json(course)
  } catch (e) {
    next(e)
  }
}

const updateCourse = async (req, res, next) => {
  try {
    const course = await Course.findByIdAndUpdate(req.params.id, req.body, { new: true })
    if (!course) throw new Error("Course not found")
    res.json(course)
  } catch (e) {
    next(e)
  }
}

const deleteCourse = async (req, res, next) => {
  try {
    await Course.findByIdAndDelete(req.params.id)
    res.json({ message: "Course deleted" })
  } catch (e) {
    next(e)
  }
}

module.exports = { getCourses, createCourse, updateCourse, deleteCourse }