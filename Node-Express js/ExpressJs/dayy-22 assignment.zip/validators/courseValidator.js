const { body, validationResult } = require("express-validator")

module.exports = [
  body("name").notEmpty(),
  body("duration").notEmpty(),
  (req, res, next) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) return res.status(400).json({ error: "Course name is required" })
    next()
  }
]