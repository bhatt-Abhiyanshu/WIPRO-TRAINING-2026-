const express = require("express")
const mongoose = require("mongoose")
const courseRoutes = require("./routes/courseRoutes")
const rateLimiter = require("./middlewares/rateLimiter")
const errorHandler = require("./middlewares/errorHandler")

mongoose.connect("mongodb://localhost:27017/dayy22")

const app = express()

app.use(express.json())
app.use(rateLimiter)

app.use("/api/v1/courses", courseRoutes)

app.use(errorHandler)

app.listen(3000)