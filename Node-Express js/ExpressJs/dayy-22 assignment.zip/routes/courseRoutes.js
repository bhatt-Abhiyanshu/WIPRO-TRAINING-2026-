const express = require("express")
const { getCourses, createCourse, updateCourse, deleteCourse } = require("../controllers/courseController")
const courseValidator = require("../validators/courseValidator")

const router = express.Router()

router.get("/", getCourses)
router.post("/", courseValidator, createCourse)
router.put("/:id", courseValidator, updateCourse)
router.delete("/:id", deleteCourse)

module.exports = router