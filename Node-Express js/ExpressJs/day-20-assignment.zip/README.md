Day 20 — Middleware & Templates

1. Install dependencies
   npm install

2. Run server
   npm start

Routes:
GET /courses → Renders courses page
POST /users → Accepts JSON or form data