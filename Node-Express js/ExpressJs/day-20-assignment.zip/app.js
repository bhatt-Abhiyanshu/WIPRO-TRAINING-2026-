const express = require("express");
const logger = require("./middleware/logger");

const app = express();

app.use(logger);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.set("view engine", "ejs");
app.set("views", "./views");

const courses = [
  { id: 1, title: "JavaScript Basics" },
  { id: 2, title: "Node.js Fundamentals" },
  { id: 3, title: "Express Middleware" }
];

app.get("/courses", (req, res) => {
  res.render("courses", { courses });
});

app.post("/users", (req, res) => {
  res.json({ message: "User created successfully", data: req.body });
});

app.listen(3000, () => {
  console.log("Server running on port 3000");
});