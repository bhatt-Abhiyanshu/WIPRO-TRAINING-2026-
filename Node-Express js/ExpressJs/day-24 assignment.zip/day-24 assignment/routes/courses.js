
const express = require('express');
const router = express.Router();

let courses = [
  { id: 1, name: "Node.js" },
  { id: 2, name: "React" }
];

router.get('/', (req, res) => {
  res.json(courses);
});

router.post('/', (req, res) => {
  const newCourse = {
    id: courses.length + 1,
    name: req.body.name
  };
  courses.push(newCourse);
  res.status(201).json(newCourse);
});

module.exports = router;
