
const chai = require('chai');
const expect = chai.expect;
const request = require('supertest');
const app = require('../app');

describe('Courses API', () => {

  it('should return all courses', async () => {
    const res = await request(app).get('/api/courses');
    expect(res.status).to.equal(200);
    expect(res.body).to.be.an('array');
  });

  it('should create a new course', async () => {
    const res = await request(app)
      .post('/api/courses')
      .send({ name: "MongoDB" });

    expect(res.status).to.equal(201);
    expect(res.body.name).to.equal("MongoDB");
  });

});
