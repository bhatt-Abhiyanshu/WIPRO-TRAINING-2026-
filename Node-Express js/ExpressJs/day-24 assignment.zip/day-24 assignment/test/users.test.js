
const chai = require('chai');
const expect = chai.expect;
const request = require('supertest');
const app = require('../app');

describe('Users API', () => {

  it('should return users list', async () => {
    const res = await request(app).get('/api/users');
    expect(res.status).to.equal(200);
    expect(res.body).to.be.an('array');
  });

  it('should create new user', async () => {
    const res = await request(app)
      .post('/api/users')
      .send({ name: "Bhatt" });

    expect(res.status).to.equal(201);
    expect(res.body.name).to.equal("Bhatt");
  });

});
