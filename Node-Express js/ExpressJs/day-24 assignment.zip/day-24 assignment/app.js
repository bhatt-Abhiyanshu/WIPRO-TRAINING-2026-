
// Main app configuration

const express = require('express');
const coursesRoute = require('./routes/courses');
const usersRoute = require('./routes/users');

const app = express();

app.use(express.json());

// Routes
app.use('/api/courses', coursesRoute);
app.use('/api/users', usersRoute);

// Status route for deployment check
app.get('/status', (req, res) => {
  res.send("App is live");
});

module.exports = app;
