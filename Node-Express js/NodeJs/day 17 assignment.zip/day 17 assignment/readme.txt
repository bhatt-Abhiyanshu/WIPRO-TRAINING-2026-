Day 17 – Introduction to Node.js & Basics

Challenge 1:
- Demonstrates hello.js execution
- Uses __filename, __dirname
- Uses setInterval and clearInterval

Challenge 2:
- npm initialized project
- Used chalk and figlet packages
- Added npm start script

Challenge 3:
- CLI app using process.argv
- Displays greeting with date & time
- Used moment package

All challenges executed successfully.
